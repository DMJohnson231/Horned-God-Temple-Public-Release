(THIS PATCH HAS ONLY BEEN CONFIRMED TO WORK ON THE MASTER QUEST DEBUG ROM. NO ROM IS INCLUDED. YOU MUST PROVIDE YOUR OWN COPY.)

Thank you for downloading my first published Ocarina of Time mod!

I started this project last year but ended up putting it down out of frustration because I couldn't get the dungeon to run smoothly, which is a shame because it was actually a VERY easy fix! But now it runs great! Trust me, I've checked!

This mod isn't supposed to be a kaizo run or anything like that. It's actually pretty simple by Zelda standards, BUT that's okay because I see it as me getting my feet wet before diving into more complicated Ocarina of Time projects. Plus, making maps for Ocarina of Time feels like artistic expression for me, and I gotta say, I love how these maps look!

So I hope you take in the atmosphere and enjoy! If you encounter any bugs or issues, feel free to let me know on Discord: @fatallyflawedhamartia

Please look forward to future projects. - Hamartia64

Credits:
Nokaubure - For creating Sharp Ocarina (the main tool used to make Ocarina of Time mods), for creating custom actors such as the Switch Platform and the Switch Timer, and for their advice!
Ultra553 - For their advice and for essentially saving this project!
CDi-Fails & hiisuya - For creating the Floor Spikes custom actor.
X Dude Awesome - For porting Majora's Mask enemies to Ocarina of Time... but I won't reveal which ones I used!
The Hylian Modding Discord - For all the help, the guidance, and the good vibes!
ColoredGreen (VGMusic) - For creating the MIDI used for the main dungeon's BGM.

Patching:
If you're looking for a way to patch your ROM, I recommend this website: https://www.marcrobledo.com/RomPatcher.js/